
from http.server import BaseHTTPRequestHandler, HTTPServer

class handler(BaseHTTPRequestHandler):
    def do_GET(self):
        print("Leaked data:", self.path)
        self.send_response(200)
        self.end_headers()

server = HTTPServer(("0.0.0.0",8000),handler)
print("Listening on port 8000")
server.serve_forever()
